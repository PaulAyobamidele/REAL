# Proposed requirement change - after run `fbf8bbcfe2d759778e6ba73d9bd43412`

Labels: **[S]** we changed the car (`performed by`), **[R]** we changed the promise (an `ensuring` soft goal added), **[D]** we changed the assumptions (an `assuming` domain assumption added, changed or dropped), **[T]** we fix the test (a scenario or scope fix - not requirement text). R1 is a proposal: edit or accept; nothing is applied automatically.

## Changes
- [S] from `DetectionTooLate` (system): "Detect Pedestrian" performed by "yolov5m"
- [R] from `BrakingNotLatched` (requirement): ensuring "once braking has started it continues until the vehicle has stopped or the pedestrian is clear"

## R0 (as run)
```
MAINTAIN "Pedestrian Safety"
    by
        "Pedestrian Check" using "Perception Module"
            operationalized as
                "Detect Pedestrian" performed by "yolov5s"
                taking input "image" producing output "pedestrian detection confidence" & "pedestrian detection flag"
    followed by
        "braking" using "braking module"
            operationalized as
                "Bring down throttle" & "Apply Brakes" if "pedestrian detection flag=True" performed by "proportional_braking"
                taking input "pedestrian detection flag" producing output "Braking Status Flag"
    in scenario where
        "A pedestrian trying to cross the street."
    assuming "fog_density <= 50" & "sun_altitude_angle >= 0" & "initial_separation_m >= 15" & "pedestrian on foot"
    ensuring "resume_within_s <= 10" & "braking is smooth unless an emergency stop is needed"
```
## R1 (proposed)
```
MAINTAIN "Pedestrian Safety"
    by
        "Pedestrian Check" using "Perception Module"
            operationalized as
                "Detect Pedestrian" performed by "yolov5m"
                taking input "image" producing output "pedestrian detection confidence" & "pedestrian detection flag"
    followed by
        "braking" using "braking module"
            operationalized as
                "Bring down throttle" & "Apply Brakes" if "pedestrian detection flag=True" performed by "proportional_braking"
                taking input "pedestrian detection flag" producing output "Braking Status Flag"
    in scenario where
        "A pedestrian trying to cross the street."
    assuming "fog_density <= 50" & "sun_altitude_angle >= 0" & "initial_separation_m >= 15" & "pedestrian on foot"
    ensuring "resume_within_s <= 10" & "braking is smooth unless an emergency stop is needed" & "once braking has started it continues until the vehicle has stopped or the pedestrian is clear"
```
## Unified diff
```diff
--- R0.dsl
+++ R1.dsl
@@ -2,7 +2,7 @@
     by
         "Pedestrian Check" using "Perception Module"
             operationalized as
-                "Detect Pedestrian" performed by "yolov5s"
+                "Detect Pedestrian" performed by "yolov5m"
                 taking input "image" producing output "pedestrian detection confidence" & "pedestrian detection flag"
     followed by
         "braking" using "braking module"
@@ -12,4 +12,4 @@
     in scenario where
         "A pedestrian trying to cross the street."
     assuming "fog_density <= 50" & "sun_altitude_angle >= 0" & "initial_separation_m >= 15" & "pedestrian on foot"
-    ensuring "resume_within_s <= 10" & "braking is smooth unless an emergency stop is needed"
+    ensuring "resume_within_s <= 10" & "braking is smooth unless an emergency stop is needed" & "once braking has started it continues until the vehicle has stopped or the pedestrian is clear"
```
